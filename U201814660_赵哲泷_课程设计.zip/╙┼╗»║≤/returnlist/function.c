#include <stdio.h>
#include "youhuahou.h"
/*�������ã�����CNF�ļ������浽�����ṹ��*/
void createByfile(clause *root,lit_position **returnlist,int lnum,int cnum,FILE *fp)
{
    int i,x,number;
	char a[10];
	literal *p=NULL;
	lit_position *q=NULL;
	for(i=0; i<cnum; i++)
	{
		number = 0;
		fscanf(fp,"%s",a);
		x = atoi(a); /*���ַ���ת��Ϊ����*/
		if(x!=0)
		{
		    if(x>0)
            {
                if(returnlist[2*x -1] == NULL)
                {
                    returnlist[2*x -1] = (lit_position *)malloc(sizeof(lit_position));
                    returnlist[2*x -1]->clause_ID = i;
                    returnlist[2*x -1]->nextposition = NULL;
                }
                else
                {
                    q=returnlist[2*x-1];
                    while(q->nextposition != NULL)
                        q = q->nextposition;
                    q->nextposition = (lit_position *)malloc(sizeof(lit_position));
                    q->nextposition->clause_ID = i;
                    q->nextposition->nextposition = NULL;
                }
            }
            else
            {
                if(returnlist[2*(-x)] == NULL)
                {
                    returnlist[2*(-x)] = (lit_position *)malloc(sizeof(lit_position));
                    returnlist[2*(-x)]->clause_ID = i;
                    returnlist[2*(-x)]->nextposition = NULL;
                }
                else
                {
                    q=returnlist[2*(-x)];
                    while(q->nextposition != NULL)
                        q = q->nextposition;
                    q->nextposition = (lit_position *)malloc(sizeof(lit_position));
                    q->nextposition->clause_ID = i;
                    q->nextposition->nextposition = NULL;
                }
            }/*��CNF��Ϣ��ÿ����������Щ�Ӿ��е���Ϣ���浽returnlist��*/
			root[i].flag = TRUE;
			p = (literal *)malloc(sizeof(literal));
			p->L = x;
			p->nextliteral = NULL;
			root[i].firstliteral = p;
			number++;
			fscanf(fp,"%s",a);
			x=atoi(a);
		}
		while(x != 0)
		{
		    if(x > 0)
            {
                if(returnlist[2*x-1] == NULL)
                {
                    returnlist[2*x-1] = (lit_position *)malloc(sizeof(lit_position));
                    returnlist[2*x-1]->clause_ID = i;
                    returnlist[2*x-1]->nextposition = NULL;
                }
                else
                {
                    q = returnlist[2*x-1];
                    while(q->nextposition != NULL)
                        q = q->nextposition;
                    q->nextposition = (lit_position *)malloc(sizeof(lit_position));
                    q->nextposition->clause_ID = i;
                    q->nextposition->nextposition = NULL;
                }
            }
            else
            {
                if(returnlist[2*(-x)] == NULL)
                {
                    returnlist[2*(-x)] = (lit_position *)malloc(sizeof(lit_position));
                    returnlist[2*(-x)]->clause_ID = i;
                    returnlist[2*(-x)]->nextposition = NULL;
                }
                else
                {
                    q = returnlist[2*(-x)];
                    while(q->nextposition != NULL)
                        q = q->nextposition;
                    q->nextposition = (lit_position *)malloc(sizeof(lit_position));
                    q->nextposition->clause_ID = i;
                    q->nextposition->nextposition = NULL;
                }
            }/*��CNF��Ϣ��ÿ����������Щ�Ӿ��е���Ϣ���浽returnlist��*/
			p->nextliteral = (literal *)malloc(sizeof(literal));
			p->nextliteral->L = x;
			p->nextliteral->nextliteral = NULL;
			p = p->nextliteral;
			number++;
			fscanf(fp,"%s",a);
			x = atoi(a);
		}
		root[i].length = number;
	}
}
/*�������ã��������ṹ��CNF��Ϣ���*/
void displayCNF(clause *root,int cnum)
{
	printf("�÷�ʽ���£�\n");
	int i = 0;
	literal *p;
	while(i < cnum)
	{
		p = root[i].firstliteral;
		printf("%d ",p->L);
		while(p->nextliteral != NULL)
		{
			p = p->nextliteral;
			printf("%d ",p->L);
		}
		i++;
		printf("\n");
	}
}
/*�������ã�ʹ��DPLL������CNF��ʽ�������*/
int DPLL(clause *root,lit_position **returnlist,int *value,int *assign,int lnum,int cnum,int tail,int v)
{
    int i,x;
    literal *p;
    if(v == 0)
    {
        inx:
        for(i=0; i<cnum; i++)
            if(root[i].flag==TRUE && root[i].length==1)
            {
                root[i].flag = FALSE;
                x = root[i].firstliteral->L;
                free(root[i].firstliteral);
                root[i].firstliteral = NULL;
                root[i].length--; /*�����Ӿ�ɾ��*/
                if(x>0) value[x] = TRUE;
                else value[-x] = FALSE; /*value��������ÿ������������״̬*/
                simplifyCNF(root,returnlist,lnum,cnum,x); /*���õ��Ӿ���Զ�root���д��ģ��*/
                goto inx;
            }
    }
    else
    {
        assign[tail++] = v; /*������β��Թ����������ֵ*/
        simplifyCNF(root,returnlist,lnum,cnum,v);
        iny:
        for(i=0; i<cnum; i++)
            if(root[i].flag == TRUE&&root[i].length == 1)
            {
                root[i].flag = FALSE;
                x = root[i].firstliteral->L;
                free(root[i].firstliteral);
                root[i].firstliteral = NULL;
                root[i].length--;
                assign[tail++] = x;
                if(x>0) value[x] = TRUE;
                else value[-x] = FALSE;
                simplifyCNF(root,returnlist,lnum,cnum,x);
                goto iny;
            }
    }
    for(i=0;i<cnum;i++)
        if(root[i].flag == TRUE) break;
    if(i==cnum) return TRUE; /*���򻯺�ķ�ʽ�Ƿ��Ӿ䶼��ɾ��*/

    for(i=0; i<cnum; i++)
        if(root[i].flag==TRUE && root[i].length==0) break;
    if(i!=cnum) return FALSE; /*���򻯺�ķ�ʽ�Ƿ��п��Ӿ�*/

    v = decide_nextlit(root,value,lnum,cnum); /*��ȡ����ѡ����һ����֧��Ԫ*/
    if(v > 0) value[v] = TRUE;
    else value[-v] = FALSE;
    /*�����Ƕ�Ӧѡȡ���ķ�֧��ԪΪ�滹��Ϊ�ٵ�������֧����*/
    if(DPLL(root,returnlist,value,assign,lnum,cnum,tail,v)==TRUE)
        return TRUE;
    else
    {
        returnCNF(root,returnlist,value,assign,tail); /*����returnlist����Ϣ������Ч����*/
        if(v > 0) value[v] = FALSE;
        else value[-v] = TRUE;
        return DPLL(root,returnlist,value,assign,lnum,cnum,tail,-v);
    }
}
/*�������ã����õ��Ӿ���ԶԷ�ʽ���м�*/
void simplifyCNF(clause *root,lit_position **returnlist,int lnum,int cnum,int x)
{
    literal *p,*q;
    lit_position *m;
    if(x>0) m=returnlist[2*x];
    else m=returnlist[2*(-x)-1]; /*�ҵ�-x������returnlist��λ�ã��Ը����Ӿ����ɾ��-x����*/
    while(m != NULL)
    {
        if(root[m->clause_ID].flag == TRUE)
        {
            p = root[m->clause_ID].firstliteral;
            while(p!=NULL && p->L==-x)
            {
                root[m->clause_ID].firstliteral = p->nextliteral;
                free(p);
                p = root[m->clause_ID].firstliteral;
                root[m->clause_ID].length--;
            }
            if(p != NULL)
            {
                q = p;
                p = p->nextliteral;
                while(p != NULL)
                {
                    if(p->L == -x)
                    {
                        q->nextliteral = p->nextliteral;
                        free(p);
                        p = q->nextliteral;
                        root[m->clause_ID].length--;
                    }
                    else
                    {
                        q = p;
                        p = p->nextliteral;
                    }
                }
            }
        }
        m = m->nextposition;
    } /*����ѡȡ���ֵ��෴ֵ�������Ӿ��еĸ��෴ֵɾȥ*/
    if(x > 0) m = returnlist[2*x-1];
    else m = returnlist[2*(-x)]; /*�ҵ�returnlist��Ӧx��λ�ã�������x���Ӿ��Ϊ��ɾ������ɾ��x������*/
    while(m != NULL)
    {
        if(root[m->clause_ID].flag == TRUE)
        {
            root[m->clause_ID].flag = FALSE;
            p = root[m->clause_ID].firstliteral;
            while(p!=NULL && p->L==x)
            {
                root[m->clause_ID].firstliteral = p->nextliteral;
                free(p);
                p=root[m->clause_ID].firstliteral;
                root[m->clause_ID].length--;
            }
            if(p != NULL)
            {
                q = p;
                p = p->nextliteral;
                while(p != NULL)
                {
                    if(p->L == x)
                    {
                        q->nextliteral = p->nextliteral;
                        free(p);
                        p = q->nextliteral;
                        root[m->clause_ID].length--;
                    }
                    else
                    {
                        q = p;
                        p = p->nextliteral;
                    }
                }
            }
        }
        m = m->nextposition;
    }/*����ѡȡ�����������Ӿ��еĸ�����ɾȥ���ҽ���Ӧ���Ӿ��ʶΪ��ɾ��*/
}
/*�������ã���������Ӿ�ԭ�򣬴��ִ�����Ӿ���ѡȡ��һ����������Ӧ�ı���Ϊ��֧��Ԫ*/
int decide_nextlit(clause *root,int *value,int lnum,int cnum)
{
    int i,j,min = lnum;
    literal *p = NULL;
    for(i=0; i<cnum; i++)
        if(root[i].flag==TRUE && root[i].length < min)
        {
            j = i;
            min = root[i].length;
        }
    for(p=root[j].firstliteral; p!=NULL; p=p->nextliteral)
        if(value[abs(p->L)] == UNCERTAIN)
            return p->L;
}
/*�������ã�����returnlist������Ч���ݣ��ָ��������һ�η�֧���Ե���ɾ�����ֵ����֡��Ӿ�*/
void returnCNF(clause *root,lit_position **returnlist,int *value,int *assign,int tail)
{
    int i,x;
    literal *p,*q;
    lit_position *m;
    for(i=tail;assign[i]!=0;i++)
    {
        x = assign[i];
        value[abs(x)] = UNCERTAIN;
        assign[i] = 0;
        if(x > 0) m = returnlist[2*x-1];
        else m = returnlist[2*(-x)];
        for(; m!=NULL; m=m->nextposition)
        {
            for(p=root[m->clause_ID].firstliteral; p!=NULL; p=p->nextliteral)
                if(p->L==x) break; /*����ӦҪ�ָ����Ӿ����д�����һ�η�֧���Թ����и�ֵ�ı�Ԫ����˵�����Ӿ䱻ɾ�����ڸ�ǰ��ķ�֧���ԣ���˲���ָ�*/
            if(p==NULL)
            {
                root[m->clause_ID].flag=TRUE;
                if(root[m->clause_ID].firstliteral==NULL)
                {
                    root[m->clause_ID].firstliteral=(literal *)malloc(sizeof(literal));
                    root[m->clause_ID].firstliteral->L=x;
                    root[m->clause_ID].firstliteral->nextliteral=NULL;
                    root[m->clause_ID].length++;
                }
                else
                {
                    p=root[m->clause_ID].firstliteral;
                    q=p->nextliteral;
                    while(q!=NULL)
                    {
                        p=q;
                        q=q->nextliteral;
                    }
                    p->nextliteral=(literal *)malloc(sizeof(literal));
                    p->nextliteral->L=x;
                    p->nextliteral->nextliteral=NULL;
                    root[m->clause_ID].length++;
                }
            } /*����ӦҪ�ָ����Ӿ���û����һ�η�֧���Թ����и�ֵ�ı�Ԫ����˵�����Ӿ䱻ɾ��������һ�εķ�֧���ԣ����ǽ����Ӿ��ʶΪ�����һָ�������*/
        }
        if(x>0) m=returnlist[2*x];
        else m=returnlist[2*(-x)-1];
        for(;m!=NULL;m=m->nextposition)
        {
            for(p=root[m->clause_ID].firstliteral;p!=NULL;p=p->nextliteral)
                if(p->L==-x) break; /*����ӦҪ�ָ����Ӿ���������һ�η�֧������ѡȡ�����ֵ��෴ֵ��˵�����Ӿ����ѱ�ɾ������˲���Ҫ�ָ�*/
            if(p==NULL)
            {
                if(root[m->clause_ID].firstliteral==NULL)
                {
                    root[m->clause_ID].firstliteral=(literal *)malloc(sizeof(literal));
                    root[m->clause_ID].firstliteral->L=-x;
                    root[m->clause_ID].firstliteral->nextliteral=NULL;
                    root[m->clause_ID].length++;
                }
                else
                {
                    p=root[m->clause_ID].firstliteral;
                    q=p->nextliteral;
                    while(q!=NULL)
                    {
                        p=q;
                        q=q->nextliteral;
                    }
                    p->nextliteral=(literal *)malloc(sizeof(literal));
                    p->nextliteral->L=-x;
                    p->nextliteral->nextliteral=NULL;
                    root[m->clause_ID].length++;
                }
            } /*����ӦҪ�ָ����Ӿ���û����һ�η�֧������ѡȡ�����ֵ��෴ֵ��˵��������������һ����ɾ���ģ���˽��лָ�*/
        }
    }
}
/*�������ã���Ԥ�ȷ���ı�����CNF��Ϣ�Ŀռ����free*/
void freeCNF(clause *root,int cnum)
{
    int i;
    literal *p,*q;
    for(i=0;i<cnum;i++)
    {
        if(root[i].length==1)
            free(root[i].firstliteral);
        if(root[i].length>1)
        {
            p=root[i].firstliteral;
            q=p->nextliteral;
            while(q!=NULL)
            {
                free(p);
                p=q;
                q=q->nextliteral;
            }
            free(p);
        }
    }
    free(root);
}
/*�������ã���Ԥ�ȷ���ı�����ÿ������������Щ�Ӿ���Ϣ�Ŀռ����free*/
void freeLit_position(lit_position **returnlist,int number)
{
    int i;
    lit_position *m,*n;
    for(i=1;i<=number;i++)
    {
        m=returnlist[i];
        if(m!=NULL)
        {
            n=m->nextposition;
            while(n!=NULL)
            {
                free(m);
                m=n;
                n=n->nextposition;
            }
            free(m);
        }
    }
    free(returnlist);
}
/*�������ã���CNF��ʽ�������DPLL����ʱ�䱣�浽�ļ���*/
void savefile(int *value,int lnum,double answer,FILE *fp)
{
    int x,i;
    char a[10],ch,ch1='\r',ch2='\n';
    ch='s';
    fprintf(fp,"%c ",ch);
    itoa(value[0],a,10);
    fprintf(fp,"%s",a);
    fprintf(fp,"%c%c",ch1,ch2);
    if(value[0]==1)
    {
        ch='v';
        fprintf(fp,"%c ",ch);
        for(i=1;i<=lnum;i++)
        {
            x=value[i];
            if(x==TRUE)
            {
                itoa(i,a,10);
                fprintf(fp,"%s ",a);
            }
            else
            {
                itoa(-i,a,10);
                fprintf(fp,"%s ",a);
            }
        }
        fprintf(fp,"%c%c",ch1,ch2);
    }
    ch='t';
    gcvt(answer,6,a);
    fprintf(fp,"%c %s",ch,a);
}
/*�������ã�������������������ն�*/
int rand_puzzle(int *puzzle,int n)
{
    int i,j,k,a;
    for(i=0;i<n;i++)
    {
        j=0;
        while(j!=n/2)
        {
            a=rand()%n+1;
            if(puzzle[a+i*n]==UNCERTAIN)
            {
                puzzle[a+i*n]=1;
                j++;
            }
        }
        for(j=1;j<=n;j++)
            if(puzzle[j+i*n]==UNCERTAIN)
                puzzle[j+i*n]=0;
    } /*�ڶ�Լ����ÿ��0��1����Ŀ�����������*/
    if(check(puzzle,n)) return TRUE;
    else
    {
        for(i=1;i<=n*n;i++)
            puzzle[i]=UNCERTAIN;
        return FALSE;
    }
}
/*�������ã��������������������ն��Ƿ���������*/
int check(int *puzzle,int n)
{
    int i,j,a,b,num;
    for(i=0;i<n;i++)
    {
        for(j=3;j<=n;j++)
            if(puzzle[i*n+j]==puzzle[i*n+j-1]&&puzzle[i*n+j-1]==puzzle[i*n+j-2]) break;
        if(j!=n+1) return FALSE;
    }
    for(j=1;j<=n;j++)
    {
        for(i=2;i<n;i++)
            if(puzzle[i*n+j]==puzzle[(i-1)*n+j]&&puzzle[(i-1)*n+j]==puzzle[(i-2)*n+j]) break;
        if(i!=n) return FALSE;
    } /*��һԼ��*/
    for(j=1;j<=n;j++)
    {
        num=0;
        for(i=0;i<n;i++)
            if(puzzle[i*n+j]==1) num++;
        if(num!=n/2) return FALSE;
    }/*�ڶ�Լ����ȷ��ÿ����0��1����Ŀ�Ƿ����*/
    for(i=0;i<n;i++)
    {
        num=0;
        for(j=1;j<=n;j++)
            if(puzzle[i*n+j]==1) num++;
        if(num!=n/2) return FALSE;
    }/*�ڶ�Լ����ȷ��ÿ����0��1����Ŀ�Ƿ����*/
    for(a=1;a<n;a++)
        for(b=a+1;b<=n;b++)
        {
            j=1;
            while(j!=n+1)
            {
                if(puzzle[(a-1)*n+j]!=puzzle[(b-1)*n+j])
                    break;
                j++;
            }
            if(j==n+1) return FALSE;
        }
    for(b=1;b<n;b++)
        for(a=b+1;a<=n;a++)
        {
            i=1;
            while(i!=n+1)
            {
                if(puzzle[(i-1)*n+b]!=puzzle[(i-1)*n+a])
                    break;
                i++;
            }
            if(i==n+1) return FALSE;
        }/*����Լ��*/
    return TRUE;
}
/*�������ã������ڿղ��Զ���������ն˱�Ϊ�о�*/
void dig_holes(int *puzzle,int n)
{
    int i,j,a;
    srand(time(NULL));
    for(i=0;i<n;i++)
        for(j=0;j<n/2+1;j++)
        {
            a=rand()%n+1;
            puzzle[i*n+a]=UNCERTAIN;
        }
}
/*�������ã��������оֵ���Ϣת��ΪCNF��Ϣ������ļ���*/
void print_CNF(int *value,int n,FILE *fp)
{
    int i,j,a=n*n,b,c,d,e,f,num=0,h[7],s;
    char ch1='\r',ch2='\n',ch3='p',ch4='0',string[10]="cnf",string1[10],string2[10],string3[10],string4[10];
    for(i=1;i<=n*n;i++)
        if(value[i]!=UNCERTAIN) num++;
    if(n==4) num=num+pre[0];
    if(n==6) num=num+pre[1];
    fprintf(fp,"%c %s ",ch3,string);
    itoa(a,string,10);
    fprintf(fp,"%s ",string);
    itoa(num,string,10);
    fprintf(fp,"%s",string);
    fprintf(fp,"%c%c",ch1,ch2);
    for(i=1;i<=n*n;i++)
    {
        if(value[i]==TRUE)
        {
            itoa(i,string,10);
            fprintf(fp,"%s %c",string,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
        }
        else if(value[i]==FALSE)
        {
            itoa(-i,string,10);
            fprintf(fp,"%s %c",string,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
        }
    } /*���Ӿ����*/
    for(i=0;i<n;i++)
        for(j=3;j<=n;j++)
        {
            itoa(i*n+j-2,string1,10),itoa(i*n+j-1,string2,10),itoa(i*n+j,string3,10);
            fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
            itoa(-i*n-j+2,string1,10),itoa(-i*n-j+1,string2,10),itoa(-i*n-j,string3,10);
            fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
        } /*��һԼ���е���Լ��*/
    for(j=1;j<=n;j++)
        for(i=2;i<n;i++)
        {
            itoa((i-2)*n+j,string1,10),itoa((i-1)*n+j,string2,10),itoa(i*n+j,string3,10);
            fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
            itoa(-(i-2)*n-j,string1,10),itoa(-(i-1)*n-j,string2,10),itoa(-i*n-j,string3,10);
            fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
        } /*��һԼ���е���Լ��*/
    if(n==4)
    {
        for(i=0;i<n;i++)
            for(c=1;c<=2;c++)
                for(d=c+1;d<=3;d++)
                    for(e=d+1;e<=4;e++)
                    {
                        itoa(i*n+c,string1,10),itoa(i*n+d,string2,10),itoa(i*n+e,string3,10);
                        fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
                        fprintf(fp,"%c%c",ch1,ch2);
                        itoa(-i*n-c,string1,10),itoa(-i*n-d,string2,10),itoa(-i*n-e,string3,10);
                        fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
                        fprintf(fp,"%c%c",ch1,ch2);
                    } /*�ڶ�Լ����n=4ʱ����Լ��*/
        for(j=1;j<=n;j++)
            for(c=0;c<2;c++)
                for(d=c+1;d<3;d++)
                    for(e=d+1;e<4;e++)
                    {
                        itoa(c*n+j,string1,10),itoa(d*n+j,string2,10),itoa(e*n+j,string3,10);
                        fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
                        fprintf(fp,"%c%c",ch1,ch2);
                        itoa(-c*n-j,string1,10),itoa(-d*n-j,string2,10),itoa(-e*n-j,string3,10);
                        fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
                        fprintf(fp,"%c%c",ch1,ch2);
                    } /*�ڶ�Լ����n=4ʱ����Լ��*/
        for(a=0;a<n-1;a++)
            for(b=a+1;b<n;b++)
                for(j=0;j<=15;j++)
                {
                    s=j;
                    h[4]=s%2,s=s/2;
                    h[3]=s%2,s=s/2;
                    h[2]=s%2,s=s/2;
                    h[1]=s%2,s=s/2;
                    for(i=1;i<=4;i++)
                    {
                        if(h[i]==1)
                        {
                            itoa(a*n+i,string1,10),itoa(b*n+i,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                        else
                        {
                            itoa(-a*n-i,string1,10),itoa(-b*n-i,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                    }
                    fprintf(fp,"%c%c%c",ch4,ch1,ch2);
                } /*����Լ����n=4ʱ����Լ��*/
        for(a=1;a<=n-1;a++)
            for(b=a+1;b<=n;b++)
                for(j=0;j<=15;j++)
                {
                    s=j;
                    h[4]=s%2,s=s/2;
                    h[3]=s%2,s=s/2;
                    h[2]=s%2,s=s/2;
                    h[1]=s%2,s=s/2;
                    for(i=0;i<4;i++)
                    {
                        if(h[i+1]==1)
                        {
                            itoa(i*n+a,string1,10),itoa(i*n+b,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                        else
                        {
                            itoa(-i*n-a,string1,10),itoa(-i*n-b,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                    }
                    fprintf(fp,"%c%c%c",ch4,ch1,ch2);
                } /*����Լ����n=4ʱ����Լ��*/
    }
    if(n==6)
    {
        for(i=0;i<n;i++)
            for(c=1;c<=3;c++)
                for(d=c+1;d<=4;d++)
                    for(e=d+1;e<=5;e++)
                        for(f=e+1;f<=6;f++)
                        {
                            itoa(i*n+c,string1,10),itoa(i*n+d,string2,10),itoa(i*n+e,string3,10),itoa(i*n+f,string4,10);
                            fprintf(fp,"%s %s %s %s %c",string1,string2,string3,string4,ch4);
                            fprintf(fp,"%c%c",ch1,ch2);
                            itoa(-i*n-c,string1,10),itoa(-i*n-d,string2,10),itoa(-i*n-e,string3,10),itoa(-i*n-f,string4,10);
                            fprintf(fp,"%s %s %s %s %c",string1,string2,string3,string4,ch4);
                            fprintf(fp,"%c%c",ch1,ch2);
                        } /*�ڶ�Լ����n=6ʱ����Լ��*/
        for(j=1;j<=n;j++)
            for(c=0;c<3;c++)
                for(d=c+1;d<4;d++)
                    for(e=d+1;e<5;e++)
                        for(f=e+1;f<6;f++)
                        {
                            itoa(c*n+j,string1,10),itoa(d*n+j,string2,10),itoa(e*n+j,string3,10),itoa(f*n+j,string4,10);
                            fprintf(fp,"%s %s %s %s %c",string1,string2,string3,string4,ch4);
                            fprintf(fp,"%c%c",ch1,ch2);
                            itoa(-c*n-j,string1,10),itoa(-d*n-j,string2,10),itoa(-e*n-j,string3,10),itoa(-f*n-j,string4,10);
                            fprintf(fp,"%s %s %s %s %c",string1,string2,string3,string4,ch4);
                            fprintf(fp,"%c%c",ch1,ch2);
                        } /*�ڶ�Լ����n=6ʱ����Լ��*/
        for(a=0;a<n-1;a++)
            for(b=a+1;b<n;b++)
                for(j=0;j<=63;j++)
                {
                    s=j;
                    h[6]=s%2,s=s/2;
                    h[5]=s%2,s=s/2;
                    h[4]=s%2,s=s/2;
                    h[3]=s%2,s=s/2;
                    h[2]=s%2,s=s/2;
                    h[1]=s%2,s=s/2;
                    for(i=1;i<=6;i++)
                    {
                        if(h[i]==1)
                        {
                            itoa(a*n+i,string1,10),itoa(b*n+i,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                        else
                        {
                            itoa(-a*n-i,string1,10),itoa(-b*n-i,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                    }
                    fprintf(fp,"%c%c%c",ch4,ch1,ch2);
                } /*����Լ����n=6ʱ����Լ��*/
        for(a=1;a<=n-1;a++)
            for(b=a+1;b<=n;b++)
                for(j=0;j<=63;j++)
                {
                    s=j;
                    h[6]=s%2,s=s/2;
                    h[5]=s%2,s=s/2;
                    h[4]=s%2,s=s/2;
                    h[3]=s%2,s=s/2;
                    h[2]=s%2,s=s/2;
                    h[1]=s%2,s=s/2;
                    for(i=0;i<6;i++)
                    {
                        if(h[i+1]==1)
                        {
                            itoa(i*n+a,string1,10),itoa(i*n+b,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                        else
                        {
                            itoa(-i*n-a,string1,10),itoa(-i*n-b,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                    }
                    fprintf(fp,"%c%c%c",ch4,ch1,ch2);
                } /*����Լ����n=6ʱ����Լ��*/
    }
}
