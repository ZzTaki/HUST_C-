#ifndef YOUHUAHOU_H_INCLUDED
#define YOUHUAHOU_H_INCLUDED

#define TRUE 1
#define FALSE 0
#define UNCERTAIN -1
typedef struct clause{
    int flag;
    int length;
    struct literal *firstliteral;
}clause; /*�Ӿ�ṹ*/
typedef struct literal{
    int L;
    struct literal *nextliteral;
}literal; /*���ֽṹ*/
typedef struct lit_position{
    int clause_ID;
    struct lit_position *nextposition;
}lit_position;
extern int pre[2];
extern void createByfile(clause *root,lit_position **returnlist,int lnum,int cnum,FILE *fp);
extern void displayCNF(clause *root,int cnum);
extern int DPLL(clause *root,lit_position **returnlist,int *value,int *assign,int lnum,int cnum,int tail,int v);
extern int decide_nextlit(clause *root,int *value,int lnum,int cnum);
extern void simplifyCNF(clause *root,lit_position **returnlist,int lnum,int cnum,int x);
extern void returnCNF(clause *root,lit_position **returnlist,int *value,int *assign,int tail);
extern void freeCNF(clause *root,int cnum);
extern void freeLit_position(lit_position **returnlist,int number);
extern void savefile(int *value,int lnum,double answer,FILE *fp);
extern int rand_puzzle(int *puzzle,int n);
extern int check(int *puzzle,int n);
extern void dig_holes(int *puzzle,int n);
extern void print_CNF(int *value,int n,FILE *fp);

#endif // YOUHUAHOU_H_INCLUDED
