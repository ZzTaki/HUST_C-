#include <stdio.h>
#include "youhuaqian.h"
/*�������ã�����CNF��ʽ��Ϣ�����浽�����ṹ��*/
void createByfile(clause *root, int cnum, FILE *fp)
{
	int i,x,number;
	char a[10];
	literal *p=NULL;
	for(i=0; i < cnum; i++)
	{
		number = 0;
		fscanf(fp, "%s", a);
		x=atoi(a);
		if(x != 0)
		{
			root[i].flag = TRUE;
			p=(literal *)malloc(sizeof(literal));
			p->L = x;
			p->nextliteral = NULL;
			root[i].firstliteral = p;
			number++;
			fscanf(fp, "%s", a);
			x=atoi(a);
		}
		while(x != 0)
		{
			p->nextliteral = (literal *)malloc(sizeof(literal));
			p->nextliteral->L = x;
			p->nextliteral->nextliteral = NULL;
			p=p->nextliteral;
			number++;
			fscanf(fp, "%s", a);
			x=atoi(a);
		}
		root[i].length = number;
	}
}
/*�������ã��������ṹ�е�CNF��Ϣ���*/
void displayCNF(clause *root, int cnum)
{
	printf("�÷�ʽ���£�\n");
	int i=0;
	literal *p;
	while(i < cnum)
	{
		p = root[i].firstliteral;
		printf("%d ", p->L);
		while(p->nextliteral != NULL)
		{
			p = p->nextliteral;
			printf("%d ", p->L);
		}
		i++;
		printf("\n");
	}
}
/*�������ã�����DPLL���CNF��ʽ*/
int DPLL(clause *root, int *value, int lnum, int cnum, int v)
{
	int i,j,x;
	literal *p,*q;
	if(v != 0)
	{
		x=v;
        for(i=0; i < cnum; i++)
            if(root[i].flag == TRUE && root[i].length > 0)
            {
                for(p = root[i].firstliteral; p != NULL; p=p->nextliteral)
                    if(p->L == x)
                    {
                        root[i].flag = FALSE;
                        break;
                    } /*�Ժ���x���Ӿ��ʶΪ�ѱ�ɾ��������ת��������һ���Ӿ�*/
                p = root[i].firstliteral;
                q = p->nextliteral;
                iny:
                if(p->L == -x)
                {
                    free(p);
                    root[i].firstliteral = q;
                    root[i].length--;
                    if(q != NULL)
                    {
                        p = q;
                        q = q->nextliteral;
                        goto iny;
                    }
                } /*�����Ӿ�ӵ�һ�����ֿ�ʼ��������-x�����*/
                else
                {
                    while(q != NULL)
                    {
                        if(q->L == -x)
                        {
                            p->nextliteral = q->nextliteral;
                            free(q);
                            q = p->nextliteral;
                            root[i].length--;
                        }
                        else
                        {
                            p = q;
                            q = q->nextliteral;
                        }
                    }
                } /*�Ժ������д��ڵ��Ӿ��е�-x����ɾ��*/
            } /*��ȡ������ʽ���������Ӿ��к���-x������ɾ����������x���Ӿ��ʶΪ�ѱ�ɾ��*/

        for(j=0; j<cnum; j++)
            if(root[j].flag == TRUE) break;
        if(j == cnum)
        {
            freeCNF(root, cnum);
            return TRUE;
        }

        for(j=0; j<cnum; j++)
            if(root[j].flag == TRUE && root[j].length == 0) break;
        if(j != cnum)
        {
            freeCNF(root, cnum);
            free(value);
            return FALSE;
        }
	}
	inx:
	for(i=0;i<cnum;i++)
		if(root[i].flag == TRUE && root[i].length == 1) /*����Ѱ�ҵ��Ӿ�*/
		{
			x = root[i].firstliteral->L;
			root[i].flag = FALSE;
			if(x>0) value[x] = TRUE;
			else value[-x] = FALSE;
			for(i=0; i<cnum; i++)
				if(root[i].flag == TRUE && root[i].length > 0)
				{
					for(p=root[i].firstliteral; p!=NULL; p=p->nextliteral)
                        if(p->L == x)
                        {
                            root[i].flag = FALSE;
                            break;
                        }
                    p = root[i].firstliteral;
                    q = p->nextliteral;
                    inz:
                    if(p->L == -x)
                    {
                        free(p);
                        root[i].firstliteral = q;
                        root[i].length--;
                        if(q != NULL)
                        {
                            p = q;
                            q = q->nextliteral;
                            goto inz;
                        }
                    }
                    else
                    {
                        while(q != NULL)
                        {
                            if(q->L == -x)
                            {
                                p->nextliteral = q->nextliteral;
                                free(q);
                                q = p->nextliteral;
                                root[i].length--;
                            }
                            else
                            {
                                p = q;
                                q = q->nextliteral;
                            }
                        }
                    }
				}
			for(j=0; j<cnum; j++)
				if(root[j].flag == TRUE) break;
			if(j == cnum)
            {
                freeCNF(root, cnum);
                return TRUE;
            } /*���CNF��ʽ�������Ӿ��Ƿ񶼱�ɾ��*/

			for(j=0; j<cnum; j++)
				if(root[j].flag == TRUE && root[j].length == 0) break;
			if(j!=cnum)
            {
                freeCNF(root, cnum);
                free(value);
                return FALSE;
            } /*����Ƿ���ڿ��Ӿ�*/
			goto inx;
		}
    clause *root1 = (clause *)malloc(cnum*sizeof(clause));
    int *value1 = (int *)malloc((lnum+1)*sizeof(int));
    for(i=1; i<=lnum; i++)
        value1[i] = value[i];
    copyCNF(root, root1, cnum); /*�ڲ�ȡ��֧����ʱ����ǰ����һ�������е�CNF��ʽһ���ķ�ʽ������ÿһ����������һ�ַ�֧���*/
	for(i=1; i<=lnum; i++)
        if(value1[i] == UNCERTAIN)
        {
            value1[i] = TRUE;
            x=i;
            if(DPLL(root1, value1, lnum, cnum, x))
            {
                for(i=1; i<=lnum; i++)
                    value[i] = value1[i];
                freeCNF(root, cnum);
                free(value1);
                return TRUE;
            }
            value[i] = FALSE;
            return DPLL(root, value, lnum, cnum, -x);
        }
}
/*�������ã�����һ��CNF��ʽ��Ϣ�����浽�����ṹ��*/
void copyCNF(clause *root, clause *root1, int cnum)
{
    int i,j;
    literal *p,*q;
    for(i=0;i<cnum;i++)
    {
        root1[i].flag=root[i].flag;
        root1[i].length=root[i].length; /*�����Ӿ�ĳ��Ⱥͱ�־*/
        if(root[i].length>0)
        {
            root1[i].firstliteral=(literal *)malloc(sizeof(literal));
            q=root1[i].firstliteral;
            p=root[i].firstliteral;
            for(j=1;j<root[i].length;j++)
            {
                q->L=p->L;
                q->nextliteral=(literal *)malloc(sizeof(literal));
                p=p->nextliteral;
                q=q->nextliteral;
            }
            q->L=p->L;
            q->nextliteral=p->nextliteral;
        }
        else
            root1[i].firstliteral=NULL; /*�����Ӿ�ĸ�������*/
    }
}
/*�������ã�free��Ԥ�ȷ���Ĵ�����CNF��Ϣ�������ṹ*/
void freeCNF(clause *root, int cnum)
{
    int i;
    literal *p,*q;
    for(i=0;i<cnum;i++)
    {
        if(root[i].length==1)
            free(root[i].firstliteral);
        if(root[i].length>1)
        {
            p=root[i].firstliteral;
            q=p->nextliteral;
            while(q!=NULL)
            {
                free(p);
                p=q;
                q=q->nextliteral;
            }
            free(p);
        }
    }
    free(root);
}
/*�������ã���DPLL������������ʱ�䱣�浽�ļ���*/
void savefile(int *value, int lnum, double answer, FILE *fp)
{
    int x,i;
    char a[10],ch,ch1='\r',ch2='\n';
    ch='s';
    fprintf(fp,"%c ",ch);
    itoa(value[0],a,10);
    fprintf(fp,"%s",a);
    fprintf(fp,"%c%c",ch1,ch2); /*����CNF��ʽ�Ƿ��н����Ϣ������ļ���*/
    if(value[0]==1)
    {
        ch='v';
        fprintf(fp,"%c ",ch);
        for(i=1;i<=lnum;i++)
        {
            x=value[i];
            if(x==TRUE)
            {
                itoa(i,a,10);
                fprintf(fp,"%s ",a);
            }
            else
            {
                itoa(-i,a,10);
                fprintf(fp,"%s ",a);
            }
        }
        fprintf(fp,"%c%c",ch1,ch2);
    } /*�н��򽫸�����������ļ���*/
    ch='t';
    gcvt(answer,6,a);
    fprintf(fp,"%c %s",ch,a);/*�����ʱ��������ļ���*/
}
/*�������ã�������������������ն�*/
int rand_puzzle(int *puzzle, int n)
{
    int i,j,k,a;
    for(i=0;i<n;i++)
    {
        j=0;
        while(j!=n/2)
        {
            a=rand()%n+1;
            if(puzzle[a+i*n]==UNCERTAIN)
            {
                puzzle[a+i*n]=1;
                j++;
            }
        }
        for(j=1;j<=n;j++)
            if(puzzle[j+i*n]==UNCERTAIN)
                puzzle[j+i*n]=0;
    } /*�ڶ�Լ����ÿ��0��1����Ŀ�����������*/
    if(check(puzzle,n)) return TRUE;
    else
    {
        for(i=1;i<=n*n;i++)
            puzzle[i]=UNCERTAIN;
        return FALSE;
    }
}
/*�������ã��������������������ն��Ƿ���������*/
int check(int *puzzle, int n)
{
    int i,j,a,b,num;
    for(i=0;i<n;i++)
    {
        for(j=3;j<=n;j++)
            if(puzzle[i*n+j]==puzzle[i*n+j-1]&&puzzle[i*n+j-1]==puzzle[i*n+j-2]) break;
        if(j!=n+1) return FALSE;
    }
    for(j=1;j<=n;j++)
    {
        for(i=2;i<n;i++)
            if(puzzle[i*n+j]==puzzle[(i-1)*n+j]&&puzzle[(i-1)*n+j]==puzzle[(i-2)*n+j]) break;
        if(i!=n) return FALSE;
    } /*��һԼ��*/
    for(j=1;j<=n;j++)
    {
        num=0;
        for(i=0;i<n;i++)
            if(puzzle[i*n+j]==1) num++;
        if(num!=n/2) return FALSE;
    }/*�ڶ�Լ����ȷ��ÿ����0��1����Ŀ�Ƿ����*/
    for(i=0;i<n;i++)
    {
        num=0;
        for(j=1;j<=n;j++)
            if(puzzle[i*n+j]==1) num++;
        if(num!=n/2) return FALSE;
    }/*�ڶ�Լ����ȷ��ÿ����0��1����Ŀ�Ƿ����*/
    for(a=1;a<n;a++)
        for(b=a+1;b<=n;b++)
        {
            j=1;
            while(j!=n+1)
            {
                if(puzzle[(a-1)*n+j]!=puzzle[(b-1)*n+j])
                    break;
                j++;
            }
            if(j==n+1) return FALSE;
        }/*����Լ�����ظ�����*/
    for(b=1;b<n;b++)
        for(a=b+1;a<=n;a++)
        {
            i=1;
            while(i!=n+1)
            {
                if(puzzle[(i-1)*n+b]!=puzzle[(i-1)*n+a])
                    break;
                i++;
            }
            if(i==n+1) return FALSE;
        }/*����Լ�����ظ�����*/
    return TRUE;
}
/*�������ã������ڿղ��Զ���������ն˱�Ϊ�о�*/
void dig_holes(int *puzzle, int n)
{
    int i,j,a;
    srand(time(NULL));
    for(i=0;i<n;i++)
        for(j=0;j<n/2+1;j++)
        {
            a=rand()%n+1;
            puzzle[i*n+a]=UNCERTAIN;
        }
}
/*�������ã��������оֵ���Ϣת��ΪCNF��Ϣ������ļ���*/
void print_CNF(int *value, int n, FILE *fp)
{
    int i,j,a=n*n,b,c,d,e,f,num=0,h[7],s;
    char ch1='\r',ch2='\n',ch3='p',ch4='0',string[10]="cnf",string1[10],string2[10],string3[10],string4[10];
    for(i=1;i<=n*n;i++)
        if(value[i]!=UNCERTAIN) num++;
    if(n==4) num=num+pre[0];
    if(n==6) num=num+pre[1];
    fprintf(fp,"%c %s ",ch3,string);
    itoa(a,string,10);
    fprintf(fp,"%s ",string);
    itoa(num,string,10);
    fprintf(fp,"%s",string);
    fprintf(fp,"%c%c",ch1,ch2);
    for(i=1;i<=n*n;i++)
    {
        if(value[i]==TRUE)
        {
            itoa(i,string,10);
            fprintf(fp,"%s %c",string,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
        }
        else if(value[i]==FALSE)
        {
            itoa(-i,string,10);
            fprintf(fp,"%s %c",string,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
        }
    } /*���Ӿ����*/
    for(i=0;i<n;i++)
        for(j=3;j<=n;j++)
        {
            itoa(i*n+j-2,string1,10),itoa(i*n+j-1,string2,10),itoa(i*n+j,string3,10);
            fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
            itoa(-i*n-j+2,string1,10),itoa(-i*n-j+1,string2,10),itoa(-i*n-j,string3,10);
            fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
        } /*��һԼ���е���Լ��*/
    for(j=1;j<=n;j++)
        for(i=2;i<n;i++)
        {
            itoa((i-2)*n+j,string1,10),itoa((i-1)*n+j,string2,10),itoa(i*n+j,string3,10);
            fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
            itoa(-(i-2)*n-j,string1,10),itoa(-(i-1)*n-j,string2,10),itoa(-i*n-j,string3,10);
            fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
            fprintf(fp,"%c%c",ch1,ch2);
        } /*��һԼ���е���Լ��*/
    if(n==4)
    {
        for(i=0;i<n;i++)
            for(c=1;c<=2;c++)
                for(d=c+1;d<=3;d++)
                    for(e=d+1;e<=4;e++)
                    {
                        itoa(i*n+c,string1,10),itoa(i*n+d,string2,10),itoa(i*n+e,string3,10);
                        fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
                        fprintf(fp,"%c%c",ch1,ch2);
                        itoa(-i*n-c,string1,10),itoa(-i*n-d,string2,10),itoa(-i*n-e,string3,10);
                        fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
                        fprintf(fp,"%c%c",ch1,ch2);
                    } /*�ڶ�Լ����n=4ʱ����Լ��*/
        for(j=1;j<=n;j++)
            for(c=0;c<2;c++)
                for(d=c+1;d<3;d++)
                    for(e=d+1;e<4;e++)
                    {
                        itoa(c*n+j,string1,10),itoa(d*n+j,string2,10),itoa(e*n+j,string3,10);
                        fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
                        fprintf(fp,"%c%c",ch1,ch2);
                        itoa(-c*n-j,string1,10),itoa(-d*n-j,string2,10),itoa(-e*n-j,string3,10);
                        fprintf(fp,"%s %s %s %c",string1,string2,string3,ch4);
                        fprintf(fp,"%c%c",ch1,ch2);
                    } /*�ڶ�Լ����n=4ʱ����Լ��*/
        for(a=0;a<n-1;a++)
            for(b=a+1;b<n;b++)
                for(j=0;j<=15;j++)
                {
                    s=j;
                    h[4]=s%2,s=s/2;
                    h[3]=s%2,s=s/2;
                    h[2]=s%2,s=s/2;
                    h[1]=s%2,s=s/2;
                    for(i=1;i<=4;i++)
                    {
                        if(h[i]==1)
                        {
                            itoa(a*n+i,string1,10),itoa(b*n+i,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                        else
                        {
                            itoa(-a*n-i,string1,10),itoa(-b*n-i,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                    }
                    fprintf(fp,"%c%c%c",ch4,ch1,ch2);
                } /*����Լ����n=4ʱ����Լ��*/
        for(a=1;a<=n-1;a++)
            for(b=a+1;b<=n;b++)
                for(j=0;j<=15;j++)
                {
                    s=j;
                    h[4]=s%2,s=s/2;
                    h[3]=s%2,s=s/2;
                    h[2]=s%2,s=s/2;
                    h[1]=s%2,s=s/2;
                    for(i=0;i<4;i++)
                    {
                        if(h[i+1]==1)
                        {
                            itoa(i*n+a,string1,10),itoa(i*n+b,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                        else
                        {
                            itoa(-i*n-a,string1,10),itoa(-i*n-b,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                    }
                    fprintf(fp,"%c%c%c",ch4,ch1,ch2);
                } /*����Լ����n=4ʱ����Լ��*/
    }
    if(n==6)
    {
        for(i=0;i<n;i++)
            for(c=1;c<=3;c++)
                for(d=c+1;d<=4;d++)
                    for(e=d+1;e<=5;e++)
                        for(f=e+1;f<=6;f++)
                        {
                            itoa(i*n+c,string1,10),itoa(i*n+d,string2,10),itoa(i*n+e,string3,10),itoa(i*n+f,string4,10);
                            fprintf(fp,"%s %s %s %s %c",string1,string2,string3,string4,ch4);
                            fprintf(fp,"%c%c",ch1,ch2);
                            itoa(-i*n-c,string1,10),itoa(-i*n-d,string2,10),itoa(-i*n-e,string3,10),itoa(-i*n-f,string4,10);
                            fprintf(fp,"%s %s %s %s %c",string1,string2,string3,string4,ch4);
                            fprintf(fp,"%c%c",ch1,ch2);
                        } /*�ڶ�Լ����n=6ʱ����Լ��*/
        for(j=1;j<=n;j++)
            for(c=0;c<3;c++)
                for(d=c+1;d<4;d++)
                    for(e=d+1;e<5;e++)
                        for(f=e+1;f<6;f++)
                        {
                            itoa(c*n+j,string1,10),itoa(d*n+j,string2,10),itoa(e*n+j,string3,10),itoa(f*n+j,string4,10);
                            fprintf(fp,"%s %s %s %s %c",string1,string2,string3,string4,ch4);
                            fprintf(fp,"%c%c",ch1,ch2);
                            itoa(-c*n-j,string1,10),itoa(-d*n-j,string2,10),itoa(-e*n-j,string3,10),itoa(-f*n-j,string4,10);
                            fprintf(fp,"%s %s %s %s %c",string1,string2,string3,string4,ch4);
                            fprintf(fp,"%c%c",ch1,ch2);
                        } /*�ڶ�Լ����n=6ʱ����Լ��*/
        for(a=0;a<n-1;a++)
            for(b=a+1;b<n;b++)
                for(j=0;j<=63;j++)
                {
                    s=j;
                    h[6]=s%2,s=s/2;
                    h[5]=s%2,s=s/2;
                    h[4]=s%2,s=s/2;
                    h[3]=s%2,s=s/2;
                    h[2]=s%2,s=s/2;
                    h[1]=s%2,s=s/2;
                    for(i=1;i<=6;i++)
                    {
                        if(h[i]==1)
                        {
                            itoa(a*n+i,string1,10),itoa(b*n+i,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                        else
                        {
                            itoa(-a*n-i,string1,10),itoa(-b*n-i,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                    }
                    fprintf(fp,"%c%c%c",ch4,ch1,ch2);
                } /*����Լ����n=6ʱ����Լ��*/
        for(a=1;a<=n-1;a++)
            for(b=a+1;b<=n;b++)
                for(j=0;j<=63;j++)
                {
                    s=j;
                    h[6]=s%2,s=s/2;
                    h[5]=s%2,s=s/2;
                    h[4]=s%2,s=s/2;
                    h[3]=s%2,s=s/2;
                    h[2]=s%2,s=s/2;
                    h[1]=s%2,s=s/2;
                    for(i=0;i<6;i++)
                    {
                        if(h[i+1]==1)
                        {
                            itoa(i*n+a,string1,10),itoa(i*n+b,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                        else
                        {
                            itoa(-i*n-a,string1,10),itoa(-i*n-b,string2,10);
                            fprintf(fp,"%s %s ",string1,string2);
                        }
                    }
                    fprintf(fp,"%c%c%c",ch4,ch1,ch2);
                } /*����Լ����n=6ʱ����Լ��*/
    }
}
